<div class="ec_details_sku"><?php echo esc_attr( $product->model_number ); ?></div>
