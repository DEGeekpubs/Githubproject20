<div class="ec_group_widget">
	
	<?php $GLOBALS['ec_categories']->print_widget_list( $groups, 0, $group_id, $store_page, $permalink_divider ); ?>

</div>