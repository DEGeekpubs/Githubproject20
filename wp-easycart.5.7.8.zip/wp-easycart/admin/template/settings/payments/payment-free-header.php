<div class="ec_admin_slider_row">
    <h1><?php esc_attr_e( 'Free Edition Gateways', 'wp-easycart' ); ?></h1>
    <div style="text-align:center;"><?php esc_attr_e( 'Bill Later is aboslutely free to use. PayPal, Stripe, and Square in our free edition each include a 2% application fee as well as the standard processing fees on all transactions. You may use Square or Stripe as your live payment method along side PayPal as your third party method. Upgrade to Pro anytime to remove the application fee!', 'wp-easycart' ); ?></div>
    <div style="text-align:center; margin:15px 0 0; font-size:18px;"><strong><?php esc_attr_e( 'Enable Bill Later, PayPal, Stripe/Square, or All 3 Methods!', 'wp-easycart' ); ?></strong></div>
</div>