<?php esc_attr_e( 'Please update your PRO plugin to access this feature.', 'wp-easycart' ); ?>
