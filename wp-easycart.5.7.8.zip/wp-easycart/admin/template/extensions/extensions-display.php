<div class="ec_admin_extensions_panel">
		
    <?php do_action( 'wpeasycart_admin_extensions_display' ); ?>

</div>