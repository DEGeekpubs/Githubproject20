<?php
class wp_easycart_admin_abandon_cart {
	public function load_abandon_cart() {
		do_action( 'wp_easycart_admin_abandon_cart_load' );
	}
}
