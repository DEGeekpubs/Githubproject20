// JavaScript Document
jQuery(document).ready(function($) {

	// Re-ordering option items
	jQuery( 'table#ec_admin_category_list tbody' ).sortable( );
	
});


